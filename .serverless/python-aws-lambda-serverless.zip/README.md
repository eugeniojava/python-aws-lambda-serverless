# python-aws-lambda-serverless
Serverless application using Python and AWS Lambda
